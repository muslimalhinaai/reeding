package om.iqra.fluency

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.util.Locale

/**
 * اقرأ بطلاقة — واجهة التطبيق صفحة HTML داخل WebView،
 * والتعرف الصوتي ونطق النص يتمّان بخدمات أندرويد الأصلية
 * (لأن WebView لا يدعم Web Speech API).
 */
class MainActivity : Activity() {

    private lateinit var web: WebView
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val ui = Handler(Looper.getMainLooper())

    /** الطالب ما زال يقرأ: نعيد تشغيل المُعرِّف تلقائيًا بعد كل جملة. */
    private var active = false
    private var endSent = true
    private var pendingStart = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
        }
        web.webViewClient = WebViewClient()
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("file:///android_asset/index.html")

        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val r = tts?.setLanguage(Locale("ar"))
                ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
                tts?.setSpeechRate(0.8f)
            }
        }
    }

    // ---------------- الجسر بين الصفحة وأندرويد ----------------
    inner class Bridge {
        @JavascriptInterface fun startListening() = ui.post { requestStart() }
        @JavascriptInterface fun stopListening() = ui.post { userStop() }
        @JavascriptInterface fun speak(text: String) = ui.post {
            if (ttsReady) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "passage")
            else js("error", "صوت القراءة العربية غير مثبّت. ثبّت «Speech Services by Google» واللغة العربية من الإعدادات.")
        }
        @JavascriptInterface fun stopSpeaking() = ui.post { tts?.stop() }
        @JavascriptInterface fun shareCsv(csv: String, name: String) = ui.post { share(csv, name) }
    }

    private fun js(fn: String, arg: String? = null) {
        val a = if (arg == null) "" else JSONObject.quote(arg)
        web.evaluateJavascript("window.nativeSpeech && window.nativeSpeech.$fn($a)", null)
    }

    // ---------------- التعرف الصوتي ----------------
    private fun requestStart() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingStart = true
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQ_MIC)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            js("error", "خدمة التعرف على الكلام غير متوفرة. ثبّت تطبيق Google أو «Speech Services by Google».")
            endSent = false; sendEnd(); return
        }
        tts?.stop()
        active = true
        endSent = false
        listenOnce()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (code == REQ_MIC && pendingStart) {
            pendingStart = false
            if (results.firstOrNull() == PackageManager.PERMISSION_GRANTED) requestStart()
            else { js("error", "يحتاج التطبيق إذن الميكروفون ليستمع إلى قراءة الطالب."); endSent = false; sendEnd() }
        }
    }

    private fun recognizerIntent() = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-SA")
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ar-SA")
        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        // الطلاب الضعاف يتوقفون كثيرًا بين الكلمات: نطلب صبرًا أطول قبل إنهاء الجملة
        putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 4000L)
        putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 3000L)
        putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 15000L)
        if (Build.VERSION.SDK_INT >= 33) putExtra(RecognizerIntent.EXTRA_MASK_OFFENSIVE_WORDS, false)
    }

    private fun listenOnce() {
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { it.setRecognitionListener(listener) }
        }
        try { recognizer?.startListening(recognizerIntent()) }
        catch (e: Exception) { js("error", "تعذّر بدء الاستماع. حاول مرة أخرى."); active = false; sendEnd() }
    }

    private fun userStop() {
        if (!active) { sendEnd(); return }
        active = false
        recognizer?.stopListening()
        // إن لم تصل نتيجة أخيرة خلال ثوانٍ ننهي المحاولة على أي حال
        ui.postDelayed({ sendEnd() }, 2500)
    }

    private fun sendEnd() {
        if (endSent) return
        endSent = true
        js("end")
    }

    private val listener = object : RecognitionListener {
        override fun onPartialResults(b: Bundle?) {
            val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: return
            if (t.isNotBlank()) js("partial", t)
        }
        override fun onResults(b: Bundle?) {
            val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (!t.isNullOrBlank()) js("final", t)
            if (active) listenOnce() else sendEnd()
        }
        override fun onError(error: Int) {
            val retry = error == SpeechRecognizer.ERROR_NO_MATCH ||
                error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT ||
                error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY ||
                error == SpeechRecognizer.ERROR_CLIENT
            if (active && retry) {
                ui.postDelayed({ if (active) { recognizer?.cancel(); listenOnce() } }, 300)
                return
            }
            if (active) {
                active = false
                js("error", when (error) {
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                        "لا يوجد اتصال بالإنترنت. نزّل حزمة العربية للتعرف دون اتصال أو اتصل بالشبكة."
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "يحتاج التطبيق إذن الميكروفون."
                    SpeechRecognizer.ERROR_AUDIO -> "تعذّر تسجيل الصوت من الميكروفون."
                    else -> "حدث خطأ في التعرف على الصوت (رمز $error)."
                })
            }
            sendEnd()
        }
        override fun onReadyForSpeech(p: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(v: Float) {}
        override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(t: Int, p: Bundle?) {}
    }

    // ---------------- مشاركة النتائج للمعلم ----------------
    private fun share(csv: String, name: String) {
        try {
            val dir = File(cacheDir, "exports").apply { mkdirs() }
            val f = File(dir, name).apply { writeText(csv, Charsets.UTF_8) }
            val uri = FileProvider.getUriForFile(this, "$packageName.files", f)
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "text/csv"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "نتائج القراءة — اقرأ بطلاقة")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(send, "مشاركة النتائج مع المعلم"))
        } catch (e: Exception) {
            js("error", "تعذّرت مشاركة الملف.")
        }
    }

    override fun onPause() {
        super.onPause()
        if (active) userStop()
        tts?.stop()
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts?.shutdown()
        web.destroy()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    companion object { private const val REQ_MIC = 7 }
}
