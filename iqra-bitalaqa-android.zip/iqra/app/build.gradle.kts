plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "om.iqra.fluency"
    compileSdk = 34

    defaultConfig {
        applicationId = "om.iqra.fluency"
        minSdk = 23
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            // للتجربة: نوقّع نسخة الإصدار بمفتاح التصحيح حتى تُثبَّت مباشرة.
            // قبل النشر في Google Play أنشئ مفتاحًا خاصًا بك.
            signingConfig = signingConfigs.getByName("debug")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
}
